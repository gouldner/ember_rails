Ember.TEMPLATES["application"] = Ember.Handlebars.compile("{{render \"navigation\"}}\n  {{outlet}}");
